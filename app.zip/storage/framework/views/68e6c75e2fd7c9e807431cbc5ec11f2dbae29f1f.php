<?php if(Session::has('message')): ?>
<div class="row">
    <div class="col-12">
        <div class="alert alert-success" role="alert"><?php echo e(Session::get('message')); ?></div>
    </div>
</div>
<?php endif; ?>

<?php /**PATH E:\iDoc\xampp\htdocs\app\resources\views/layouts/shared/alert.blade.php ENDPATH**/ ?>