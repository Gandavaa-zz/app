<?php $__env->startSection('content'); ?>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
        <div class="container-fluid">
          <div class="animated fadeIn">
            <div class="row">
              <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <div class="card">
                    <div class="card-header">
                    <span class="float-left"><h5><i class="fa fa-align-justify"></i><?php echo e(__('Харилцагчид')); ?></h5></span> <span class="float-right">
                    <button type="button" id="deleteMultiple" class="btn btn-danger deleteMultiple"  href="javascript:void(0)" data-original-title="Delete">Олноор устгах</button>
                    <a class="btn btn-primary" href="<?php echo e(route('participants.create')); ?>"><i class="cil-plus"></i>Шинэ</a></span>

                    </div>

                    <div class="card-body">
                    <?php echo $__env->make('layouts.shared.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <form action="<?php echo e(route('candidate.index')); ?>" method="GET" id="group">
                        <div class="form-group col-md-4">
                            <select class="form-control" id="selectgroup" name="group_id">
                                <option value="0">Сонгох...</option>
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php if($group_id==$key->id): ?> <?php echo e('selected'); ?> <?php endif; ?> value="<?php echo e($key->id); ?>"><?php echo e($key->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </form>

                        <table class="table table-bordered yajra-datatable user_table " id="user_table" style="width: 100%; font-size:13.5px;">
                            <thead>
                                <tr>
                                    <th width="3px"><input type="checkbox" id="selectAll"/></th>
                                    <!-- <th width="5px">#</th> -->
                                    <th>Нэвтрэх нэр</th>
                                    <th>Нэр</th>
                                    <th>Овог</th>
                                    <th>Имэйл</th>
                                    <th>Бүлэг</th>
                                    <th>Үйлдэл</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($canditateList): ?>
                                    <?php $__currentLoopData = $canditateList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->id); ?></td>
                                        <td><?php echo e($item->login); ?></td>
                                        <td><?php echo e($item->firstname); ?></td>
                                        <td><?php echo e($item->lastname); ?></td>
                                        <td><?php echo e($item->email); ?></td>
                                        <td>
                                            <?php $__currentLoopData = $item->groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($group->name); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td>
                                            <a href="/candidate/assesments/<?php echo e($item->id); ?>" class="btn btn-primary" title="Өгсөн тестүүдийг харах"><i class="text-white cil-list-numbered"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                            </tbody>
                        </table>
                        <div class="modal fade" id="groupModal" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog .modal-dialog-centered" role="document">
                              <div class="modal-content">
                                  <div class="modal-header">
                                      <h4 class="modal-title">Групп-д нэмэх</h4>
                                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                      </button>
                                  </div>
                                  <div class="modal-body">
                                    <div class="form-group">
                                        <form method="POST" action="">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="user_id" id="user_id">
                                            <div class="form-group row">
                                                <label for="groups" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Групп')); ?></label>
                                                <div class="col-md-8">
                                                    <group  class="<?php $__errorArgs = ['groups'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></group>
                                                    <?php $__errorArgs = ['groups'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                            <button type="submit" class="btn btn-success" >Хадгалах</button>
                                            </div>
                                      </form>
                                    </div>
                                  </div>
                              </div>
                            </div>
                          </div>

                      
                    </div>
                </div>
              </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<style>
    div.dataTables_wrapper div.dataTables_length select {
    width: 60px!important;
    display: inline-block;
}
</style>

<script>

$(function () {

    $("#selectgroup").select2();

    $('#selectgroup').on('select2:select', function (e) {
        var data = e.params.data;
        console.log(data.id);
        // ajax sent
        $( "#group" ).submit();
    });

    // var table = $('.yajra-datatable').DataTable({
    //     processing: true,
    //     serverSide: true,
    //     ajax: "<?php echo e(route('participants.index')); ?>",
    //     columns: [
    //         {
    //             data: 'checkbox',
    //             name: 'checkbox',
    //             orderable: false,
    //             searchable: false
    //         },
    //         {
    //             data: 'fullname',
    //             name: 'fullname',
    //             render: function(data, type, row) {
    //                 return "<a style='color:#4F5D73;font-weight:bold' href='/participants/"+ row.id +"'>" + row.fullname + "</a>"
    //             }
    //         },
    //         {
    //             data: 'email',
    //             name: 'email'
    //         },
    //         {
    //             data: 'company',
    //             name: 'company'
    //         },
    //         {
    //             data: 'created_at',
    //             name: 'created_at'
    //         },

    //         {
    //             data: "test",
    //             name: "test"
    //         },
    //         {
    //             data: 'action',
    //             name: 'action',
    //             orderable: true,
    //             searchable: true

    //         },
    //     ]
    // });

});


$(document).ready(function () {
  $('body').on('click', '.addToGroup', function () {
    var id  = $(this).data('id');
    $('#user_id').val(id);
    $('#groupModal').modal('show');
    // alert(id);
  })
});

$(document).ready(function () {
  $('body').on('click', '#selectAll', function () {
    if ($(this).hasClass('allChecked')) {
        $('input[type="checkbox"]', '#user_table').prop('checked', false);
    } else {
        $('input[type="checkbox"]', '#user_table').prop('checked', true);
    }
    $(this).toggleClass('allChecked');
  })
});

$(document).on('click', '#deleteMultiple', function(){
    var id = [];
    Swal.fire({
        title: 'Are you sure?',
        // text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Тийм',
        cancelButtonText: 'Үгүй'
    }).then((result) => {
    if (result.value) {
        $('.participant_checkbox:checked').each(function(){
            id.push($(this).val());
        });

        if(id.length > 0)
        {
            $.ajax({
                url:"<?php echo e(route('participants.deleteMultiple')); ?>",
                method:"get",
                data:{id:id},
                success:function(data)
                {
                    Swal.fire(
                        'Deleted!',
                        'Амжилттай устгагдлаа',
                        'success')
                    $('#user_table').DataTable().ajax.reload();
                }
            });
        }
        else
        {
            Swal.fire({
            icon: 'error',
            title: 'Алдаа...',
            text: 'Харилцагч сонгоно уу!'
            })
        };
        }
    })
    });


$('body').on('click', '.delete', function () {
var id = $(this).data("id");
//  var firstname = $(this).data("firstname");
//  console.log("participant id - " + id);
 Swal.fire({
    title: 'Are you sure?',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Тийм',
    cancelButtonText: 'Үгүй'
}).then((result) => {
  if (result.value) {
    $.ajax({
       type: "get",
       url:"participants/destroy/"+id,
       success: function (data) {
        setTimeout(function(){
     $('#confirmModal').modal('hide');
     $('#user_table').DataTable().ajax.reload();
    });
       },
       error: function (data) {
           console.log('Error:', data);
       }
   });
    Swal.fire(
      'Deleted!',
      'Амжилттай устгагдлаа',
      'success'
    )
  }
})

$('#select_all').click(function(event) {
    var $that = $(this);

    $(':checkbox').each(function() {
        this.checked = $that.is(':checked');
    });
});


  function addPost() {
    $('#add-group-modal').modal('show');
  }


});
</script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\iDoc\xampp\htdocs\app\resources\views/layouts/candidate/list.blade.php ENDPATH**/ ?>