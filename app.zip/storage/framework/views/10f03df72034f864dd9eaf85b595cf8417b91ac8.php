    <div class="c-subheader px-3">
      <ol class="breadcrumb border-0 m-0">
          <li class="breadcrumb-item"><a href="/">Нүүр</a></li>
          <?php $segments = ''; ?>

          <?php for($i = 1; $i <= count(Request::segments()); $i++): ?> <?php $segments .= '/'. getBreadcrumb(Request::segment($i)); ?>
              <?php if($i < count(Request::segments())): ?> <li class="breadcrumb-item"><?php echo e(getBreadcrumb(Request::segment($i))); ?></li>
              <?php else: ?>
              <li class="breadcrumb-item active"><?php echo e(getBreadcrumb(Request::segment($i))); ?></li>
              <?php endif; ?>
              <?php endfor; ?>
      </ol>
  </div>
<?php /**PATH E:\iDoc\xampp\htdocs\app\resources\views/layouts/shared/breadcrumb.blade.php ENDPATH**/ ?>