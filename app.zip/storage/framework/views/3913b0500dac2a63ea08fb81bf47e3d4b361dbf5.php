<?php $__env->startSection('content'); ?>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
        <div class="container-fluid">
          <div class="animated fadeIn">
            <div class="row">
              <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <div class="card">
                    <div class="card-header">
                    <span class="float-left"><h5><i class="fa fa-align-justify"></i><?php echo e(__('Харилцагчид')); ?></h5></span> <span class="float-right">
                    <button type="button" id="deleteMultiple" class="btn btn-danger deleteMultiple"  href="javascript:void(0)" data-original-title="Delete">Олноор устгах</button>
                    <a class="btn btn-primary" href="<?php echo e(route('participants.create')); ?>"><i class="cil-plus"></i>Шинэ</a></span>

                    </div>

                    <div class="card-body">
                    <?php echo $__env->make('layouts.shared.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <table class="table table-bordered yajra-datatable user_table " id="user_table" style="width: 100%; font-size:13.5px;">
                            <thead>
                                <tr>
                                    <th>Шалгалтын #</th>
                                    <th>Тест </th>
                                    <th>Шалгалт эхэлсэн огноо</th>
                                    <th>Шалгалт дууссан огноо</th>
                                    <th>Үнэлсэн</th>
                                    <th>Тайлан холбоос</th>
                                    <th>Тайлан pdf холбоос</th>
                                    <th>Үйлдэл</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($assesments): ?>
                                    <?php $__currentLoopData = $assesments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assesment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($assesment->id); ?></td>
                                        <td><?php echo e($assesment->test); ?></td>
                                        <td><?php echo e($assesment->assessment_start_date); ?></td>
                                        <td><?php echo e($assesment->assessment_end_date); ?></td>
                                        <td><?php echo e($assesment->candidate_evaluator); ?></td>
                                        <td>
                                            <a href="<?php echo e($assesment->candidate_report_link); ?>">Тайлан холбоос</a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e($assesment->candidate_report_pdf_link); ?>">Тайлан PDF холбоос</a>
                                        </td>
                                        <td>
                                            <a href="/scores/global/<?php echo e($assesment->id); ?>" title="Global оноо" class="btn btn-primary"><i class="cil-description"></i></a>
                                            <a href="/scores/factory/<?php echo e($assesment->id); ?>" title="Factory оноо" class="btn btn-primary"><i class="cil-description"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                            </tbody>
                        </table>

                    </div>
                </div>
              </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\iDoc\xampp\htdocs\app\resources\views/layouts/candidate/tests.blade.php ENDPATH**/ ?>