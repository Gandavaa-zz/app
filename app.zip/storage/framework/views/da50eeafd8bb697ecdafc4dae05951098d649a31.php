<?php $__env->startSection('content'); ?>

        <div class="container-fluid">
          <div class="animated fadeIn">
            <div class="row">
              <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <span class="float-left"><h5><i class="fa fa-align-justify"></i><?php echo e(__('Тест')); ?></h5></span> <span class="float-right">
                    </div>
                    <div class="card-body">
                        <table class="table table-responsive-sm table-striped test-table">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Төрөл</th>
                            <th scope="col">Тест нэр</th>
                            <th scope="col">Лого</th>
                            <th scope="col">Кредит</th>
                            <th scope="col">Үйлдэл</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php ($i = 1); ?>
                            <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($test->id); ?> </th>
                                <td><?php echo e($test->category); ?></td>
                                <td><?php echo e($test->label); ?></td>
                                <td><img src="<?php echo e($test->logo); ?>" alt=""></td>
                                <td><?php echo e($test->duration); ?></td>
                                <td><?php echo e($test->price_in_credits); ?></td>
                                <td>
                                    <!-- <a href="#" class="btn btn-primary btn-sm" title="Add"><i class="fas fa-plus"></i></a>                     -->
                                    <a href="/admin/tests/<?php echo e($test->id); ?>/edit" class="btn btn-primary btn-sm" title="Edit"><i class="faы fa-pencil-alt"></i></a>
                                    <a href="#" class="btn btn-danger btn-sm" title="Edit"><i class="fas fa-trash-alt"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                        <div>
                            <?php echo e($tests->links()); ?>

                        </div>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript'); ?>
<script>
// $(function () {

// var table = $('.test-table').DataTable({
//     processing: true,
//     serverSide: true,
//     ajax: "<?php echo e(route('settings.test')); ?>",
//     columns: [{
//             data: 'DT_RowIndex',
//             name: 'DT_RowIndex'
//         },
//         {
//             data: 'firstname',
//             name: 'firstname'
//         },
//         {
//             data: 'email',
//             name: 'email'
//         },
//         {
//             data: 'created_at',
//             name: 'created_at'
//         },
//         {
//             data: 'name',
//             name: 'name'
//         },
//         {
//             data: 'action',
//             name: 'action',
//             orderable: true,
//             searchable: true

//         },
//     ]
// });

// });

</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\iDoc\xampp\htdocs\app\resources\views/layouts/test/list.blade.php ENDPATH**/ ?>