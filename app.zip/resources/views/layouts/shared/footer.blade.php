<footer class="c-footer">
  <div><a href="https://unitedconsulting.mn">United Consulting Management</a> &copy; 2020 All rights Reserved.</div>
  <div class="ml-auto">Developed by &nbsp;<a href="https://proverbs.io/">Proverbs</a></div>
</footer>